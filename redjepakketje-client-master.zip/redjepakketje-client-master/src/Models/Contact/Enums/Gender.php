<?php

declare(strict_types=1);

namespace JacobDeKeizer\RedJePakketje\Models\Contact\Enums;

interface Gender
{
    public const FEMALE = 'f';
    public const MALE = 'm';
}
