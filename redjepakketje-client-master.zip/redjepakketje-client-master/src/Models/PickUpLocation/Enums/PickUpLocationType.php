<?php

declare(strict_types=1);

namespace JacobDeKeizer\RedJePakketje\Models\PickUpLocation\Enums;

interface PickUpLocationType
{
    public const PICK_UP_POINT = 'PICK_UP_POINT';
}
