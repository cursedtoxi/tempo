<?php

declare(strict_types=1);

namespace JacobDeKeizer\RedJePakketje\Parameters;

use JacobDeKeizer\RedJePakketje\Contracts\Parameter;
use JacobDeKeizer\RedJePakketje\Models\BaseModel;

abstract class BaseParameter extends BaseModel implements Parameter
{

}
