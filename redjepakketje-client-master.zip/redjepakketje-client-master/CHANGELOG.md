# Change log

## v2.0.0
- Upgraded to v2 of Red je Pakketje api.
- Upgraded to PHP 8.0
- Rewrite of endpoints and models, see readme for new implementation details.
